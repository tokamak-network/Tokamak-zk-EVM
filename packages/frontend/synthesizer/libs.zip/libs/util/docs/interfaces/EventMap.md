[@ethereumjs/util](../README.md) / EventMap

# Interface: EventMap

## Indexable

▪ [event: `string`]: `AsyncListener`<`any`, `any`\>
