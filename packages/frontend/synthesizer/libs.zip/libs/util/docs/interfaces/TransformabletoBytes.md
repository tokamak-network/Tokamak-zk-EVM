[@ethereumjs/util](../README.md) / TransformabletoBytes

# Interface: TransformabletoBytes

## Table of contents

### Methods

- [toBytes](TransformabletoBytes.md#tobytes)

## Methods

### toBytes

▸ `Optional` **toBytes**(): `Uint8Array`

#### Returns

`Uint8Array`

#### Defined in

[packages/util/src/types.ts:34](https://github.com/ethereumjs/ethereumjs-monorepo/blob/master/packages/util/src/types.ts#L34)
